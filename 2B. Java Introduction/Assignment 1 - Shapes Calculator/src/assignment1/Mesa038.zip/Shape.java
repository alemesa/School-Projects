package assignment1;

	public interface Shape {
		
	    public double perimeter();
	    
	    //public double area();
	    
	}

