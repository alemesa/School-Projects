<?php
/**
 * English language file for template
 *
 */

$lang['menu'] = 'Menu';
$lang['__theme_color__'] = 'Primary theme colour';
$lang['__theme_color_alt__'] = 'Secondary theme colour';
$lang['__content_width__'] = 'Width of the content area';
