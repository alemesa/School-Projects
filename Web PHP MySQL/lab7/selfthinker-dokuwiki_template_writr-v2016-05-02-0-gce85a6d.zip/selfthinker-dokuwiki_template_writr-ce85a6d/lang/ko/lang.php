<?php
/**
 * Korean language file for template
 *
 */

$lang['menu'] = '메뉴';
$lang['__theme_color__'] = '첫째 테마 색';
$lang['__theme_color_alt__'] = '둘째 테마 색';
$lang['__content_width__'] = '내용 영역의 너비';
