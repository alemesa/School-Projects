# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated


admin:$1$OUKlIIZz$zwye0z1SAtNzICPTN.7ks/:Super Admin:superadmin@mail.com:admin,user
spiderman:$1$STnwBV7O$y5V5Gc48V0W65Z6oEX0UO1:Spiderman:spiderman@mail.com:user
ironman:$1$oC8a6FSU$zugPwKzIt..r/No8j292g.:Iron Man:ironman@gmail.com:user
godzilla:$1$jyLpz9qS$wantv9fmLiJN/2.YdTOjn1:Godzilla:godzilla@gmail.com:user
captainamerica:$1$4vVzyZgE$9C87Zma0dT6xj/l7.iUl90:Captain America:captainamerica@gmail.com:user
blackwidow:$1$7BaZEtCG$j/024IVoSQCLcv..NxpiU0:Black Widow:blackwidow@gmail.com:user
