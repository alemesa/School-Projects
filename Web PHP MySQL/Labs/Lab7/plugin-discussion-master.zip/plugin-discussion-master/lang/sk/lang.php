<?php
/**
 * Slovak language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Pirhala Marek <mpirhala@genesispo.sk>
 */

$lang['discussion']      = 'Diskusia';
$lang['btn_reply']       = 'Odpoveď';
$lang['btn_hide']        = 'Skryť';
$lang['btn_show']        = 'Zobraziť';
$lang['wordblock']       = 'Váš príspevok bol blokovaný ako spam.';
$lang['mail_newcomment'] = 'Nový komentár';

$lang['reply']           = 'Odpoveď';
$lang['replies']         = 'Odpovede';
$lang['newthread']       = 'Nové vlákno';

//Setup VIM: ex: et ts=2 enc=utf-8 :
