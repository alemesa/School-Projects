<?php
/**
 * Slovak language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Pirhala Marek <mpirhala@genesispo.sk>
 */
 
// for the configuration manager
$lang['allowguests'] = 'povoliť komentáre neregistrovaným';
$lang['linkemail']   = 'linkovať mená komentujúcich s e-mailami';
$lang['useavatar']   = 'použiť obrázky gavatar';

//Setup VIM: ex: et ts=2 enc=utf-8 :
