<?php
/**
 * Slovenian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Blaž Mertelj <Blaz.Mertelj@atol.si>
 */

$lang['discussion'] = 'Diskusija';
$lang['comment']    = 'Komentar';
$lang['comments']   = 'Komentarji';

//Setup VIM: ex: et ts=2 enc=utf-8 :
