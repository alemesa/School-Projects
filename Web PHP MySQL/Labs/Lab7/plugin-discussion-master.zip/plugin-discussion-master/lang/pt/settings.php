<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Adriano Afonso <mail@adrianoafonso.net>
 */
$lang['allowguests']           = 'permitir comentários de utilizadores não registados';
$lang['linkemail']             = 'adicionar ligação para correio electrónico dos utilizadores';
$lang['useavatar']             = 'utilizar avatares dos utilizadores nos comentários';
